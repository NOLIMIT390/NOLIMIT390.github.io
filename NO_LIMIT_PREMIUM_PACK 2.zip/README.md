# NO LIMIT — Premium starter kit
- `index.html` : landing page premium noir/vert.
- `01_custom_plan.pdf` : modèle de planning.
- `02_30_day_progress.pdf` : modèle de suivi.
- `03_8_week_performance.pdf` : cadre de progression.

Publication : dépôt public `NOLIMIT390.github.io`, téléverser `index.html` à la racine, puis Settings → Pages → Deploy from a branch → `main` → `/ (root)`.

Limites : prototype statique. Le formulaire ouvre le logiciel e-mail du visiteur; aucun paiement Stripe, stockage de données, génération ou envoi automatique de PDF n'est connecté. Ne place aucune clé secrète ni donnée client dans ce dépôt public. Compléter les mentions légales, la confidentialité, les conditions de vente et informations de rétractation avant commercialisation. Personnaliser et vérifier chaque programme; ne pas prétendre à des qualifications non détenues.
